<?php  

sleep(3);

header("Location: ./account.html");
?>

